Course Evaluation

Frontend-only

How to run

1. Install dependencies:

```bash
npm install
```

2. Start dev server:

```bash
npm run dev
```
